from django.apps import AppConfig


class TosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tos'

    def ready(self):
        import tos.signals

